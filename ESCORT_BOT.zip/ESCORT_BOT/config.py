# Bot Token'ını buraya yaz
BOT_TOKEN = "7847386023:AAHkyscfv9vkhAD6y89TKYvF6VZ6t6697Rw"  # ⚠️ DEĞİŞTİR!

# Admin ID (kendi Telegram ID'n)
ADMIN_IDS = [7536095127]  # ⚠️ DEĞİŞTİR!

# Veritabanı yolu
DATABASE_PATH = "data/escort_bot.db"

# Şehirler
CITIES = ["İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Diğer Şehirler"]

# Yaş Aralıkları
AGE_RANGES = ["18-23", "24-28", "29-35", "35+"]

# Boy Aralıkları
HEIGHT_RANGES = ["150-160", "160-170", "170-180", "180+"]

# Uyruklar
NATIONALITIES = ["Türk", "Rus", "Ukraynalı", "Rumen", "Afrika", "Latin", "Diğer"]